package org.zkoss.theme.atlantic;

public class Version {
	/** Returns the version UID.
	 */
	public static final String UID = "0.8.0";
}
